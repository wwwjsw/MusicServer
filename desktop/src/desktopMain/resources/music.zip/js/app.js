class AudioPlayer {
  constructor() {
    this.audio = new Audio();
    this.playlist = [];
    this.currentTrack = 0;
    this.isPlaying = false;
    // Use relative URLs so the player works on any IP/port
    this.initializeElements();
    this.setupEventListeners();
    this.loadPlaylist();
  }

  initializeElements() {
    this.playlistElement = document.getElementById('playlist');
    this.playButton = document.getElementById('playButton');
    this.prevButton = document.getElementById('prevButton');
    this.nextButton = document.getElementById('nextButton');
    this.progressBar = document.getElementById('progressBar');
    this.progressContainer = document.getElementById('progressContainer');
    this.currentTimeElement = document.getElementById('currentTime');
    this.durationElement = document.getElementById('duration');
    this.songInfoElement = document.getElementById('songInfo');
    this.volumeSlider = document.getElementById('volumeSlider');
  }

  setupEventListeners() {
    this.playButton.addEventListener('click', () => this.togglePlay());
    this.prevButton.addEventListener('click', () => this.playPrevious());
    this.nextButton.addEventListener('click', () => this.playNext());
    this.volumeSlider.addEventListener('input', (e) => this.setVolume(e.target.value));

    this.audio.addEventListener('timeupdate', () => this.updateProgress());
    this.audio.addEventListener('ended', () => this.playNext());
    this.audio.addEventListener('loadedmetadata', () => {
      this.durationElement.textContent = this.formatTime(this.audio.duration);
    });

    this.progressContainer.addEventListener('click', (e) => this.seek(e));
  }

  async loadPlaylist() {
    try {
      const response = await fetch('/music');
      const data = await response.json();
      this.playlist = data.data;
      this.renderPlaylist();
    } catch (error) {
      console.error('Error loading playlist:', error);
    }
  }

  renderPlaylist() {
    this.playlistElement.innerHTML = this.playlist
      .map((track, index) => `
        <div class="playlist-item ${index === this.currentTrack ? 'active' : ''}"
             data-index="${index}"
             onclick="player.playTrack(${index})">
          <span>${track.title}</span>
          <span style="color:#888;font-size:12px">${track.artist}</span>
        </div>
      `).join('');
  }

  async playTrack(index) {
    if (index < 0 || index >= this.playlist.length) return;

    this.currentTrack = index;
    const track = this.playlist[index];
    this.songInfoElement.textContent = `${track.title} - ${track.artist}`;
    this.renderPlaylist();

    // Use the audio element src directly with range support
    // instead of fetching a blob — allows seeking without loading entire file
    this.audio.src = `/music?audio_id=${track.id}`;
    this.audio.load();
    try {
      await this.audio.play();
      this.isPlaying = true;
      this.playButton.textContent = '⏸';
    } catch (error) {
      console.error('Error playing track:', error);
    }
  }

  togglePlay() {
    if (this.audio.src) {
      if (this.isPlaying) {
        this.audio.pause();
        this.playButton.textContent = '▶';
      } else {
        this.audio.play();
        this.playButton.textContent = '⏸';
      }
      this.isPlaying = !this.isPlaying;
    } else if (this.playlist.length > 0) {
      this.playTrack(0);
    }
  }

  playPrevious() {
    const newIndex = (this.currentTrack - 1 + this.playlist.length) % this.playlist.length;
    this.playTrack(newIndex);
  }

  playNext() {
    const newIndex = (this.currentTrack + 1) % this.playlist.length;
    this.playTrack(newIndex);
  }

  updateProgress() {
    if (!this.audio.duration) return;
    const progress = (this.audio.currentTime / this.audio.duration) * 100;
    this.progressBar.style.width = `${progress}%`;
    this.currentTimeElement.textContent = this.formatTime(this.audio.currentTime);
  }

  seek(event) {
    const rect = this.progressContainer.getBoundingClientRect();
    const pos = (event.clientX - rect.left) / rect.width;
    this.audio.currentTime = pos * this.audio.duration;
  }

  setVolume(value) {
    this.audio.volume = value / 100;
  }

  formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
}

let player;
document.addEventListener('DOMContentLoaded', () => {
  player = new AudioPlayer();
});
